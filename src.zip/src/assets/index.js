export { default as worker } from "./worker.jpg";
export { default as workerTwo } from "./worker2.jpg";
export { default as warehouse } from "./warehouse.jpg";
export { default as logo } from "./onkron_rgb.png";
export { default as industrialrobot } from "./industrial-robot.svg";
export { default as loader } from "./loader.svg";
export { default as pushcart } from "./pushcart.svg";
export { default as warehousesvg } from "./warehouse.svg";
export { default as workersvg } from "./worker.svg";
export { default as box } from "./box.svg";
export { default as car } from "./car.svg";
export { default as pc } from "./pc.svg";
export { default as phone } from "./phone.svg";
export { default as indexInfoBanner } from "./indexInfoBanner.svg";
export { default as s1 } from "./s1.svg";
export { default as s2 } from "./s2.svg";
export { default as s3 } from "./s3.svg";
export { default as s4 } from "./s4.svg";
export { default as s5 } from "./s5.svg";
export { default as s6 } from "./s6.svg";
export { default as ad } from "./24.svg";
export { default as doc } from "./doc.svg";

export { default as st1 } from "./st1.webp";
export { default as st2 } from "./st2.webp";
export { default as st3 } from "./st3.webp";

export { default as trust } from "./trust.jpg";
export { default as truck } from "./truck.svg";
export { default as conveyor } from "./conveyor.svg";
export { default as stock } from "./stock.svg";

export { default as amazon } from "./amazon.webp";
export { default as ebay } from "./ebay.png";
export { default as shopify } from "./shopify.png";


export { default as topStash } from "./top-stash.webp";
export { default as botStash } from "./bot-stash.webp";

export { default as gruz } from "./gruz.webp";
export { default as gruzT } from "./truck.jpg";
