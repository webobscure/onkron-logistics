import React from 'react'
import Blog from './Blog'

export default function News() {
  return (
    <>
            <Blog />
    </>
  )
}
