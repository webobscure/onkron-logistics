
export {default as Sklad} from './Sklad/Sklad';

